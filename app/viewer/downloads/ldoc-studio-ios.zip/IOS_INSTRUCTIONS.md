# LDOC Studio for iOS / iPadOS

## Installation Options:
1. **Safari WebKit Standalone (Recommended)**:
   - Open `index.html` on your iOS device or host via local Wi-Fi / Files app.
   - Tap Safari **Share** -> **Add to Home Screen**.
   - LDOC Studio launches as a full-screen, hardware-accelerated Touch app with full offline support.
2. **Xcode WebKit Wrapper**:
   - Embed this folder into an iOS WKWebView project for native App Store deployment.
