#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if command -v xdg-open > /dev/null; then
  xdg-open "$DIR/index.html"
elif command -v sensible-browser > /dev/null; then
  sensible-browser "$DIR/index.html"
elif command -v python3 > /dev/null; then
  python3 -m webbrowser "$DIR/index.html"
else
  echo "Please open $DIR/index.html in any modern web browser."
fi
