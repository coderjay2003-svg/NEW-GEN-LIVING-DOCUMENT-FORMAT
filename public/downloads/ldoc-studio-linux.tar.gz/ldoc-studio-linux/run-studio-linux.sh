#!/usr/bin/env bash
# LDOC Studio Linux Launcher
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
echo "Starting LDOC Studio Pro (Linux)..."
if command -v xdg-open > /dev/null; then
    xdg-open "file://$DIR/index.html"
elif command -v sensible-browser > /dev/null; then
    sensible-browser "file://$DIR/index.html"
else
    python3 -m http.server 8080 --directory "$DIR"
fi
